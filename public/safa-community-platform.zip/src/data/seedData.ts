import {
  FounderProfile,
  SocialLink,
  ImpactStatistic,
  Program,
  WorkItem,
  Story,
  HistoryEntry,
  Contribution,
  TransparencyReport,
  DonationBankConfig,
  User,
  Article,
  VideoItem,
  PhotoAlbum,
  MediaAsset,
  Announcement,
  AdminInvitation,
  EventItem,
  DonationCampaign
} from '../types';

export const INITIAL_FOUNDER_PROFILE: FounderProfile = {
  name: 'Nargiza',
  title: 'Founder & CEO of SAFA',
  organization: 'SAFA Community Support Platform',
  quote:
    'CEO of SAFA — turning compassion into meaningful action. Nargiza leads the vision behind every visit, drive, and connection SAFA makes.',
  biography:
    'Nargiza founded SAFA with the conviction that genuine empathy must translate into direct, practical action. By bringing together dedicated youth volunteers and local community members across Uzbekistan, she leads SAFA in bridging the gap between those who wish to extend help and individuals facing urgent life challenges.',
  imageUrl: '/nargiza_ceo.jpg',
  linkedinUrl:
    'https://www.linkedin.com/in/safa-uzbekistan-63080b432?utm_source=share_via&utm_content=profile&utm_medium=member_ios',
  telegramUrl: 'https://t.me/SafaUzbekistan',
  email: 'safaauzb@gmail.com',
  phone: '+998 90 123 45 67',
  address: 'Tashkent, Republic of Uzbekistan',
  mission: 'Connecting hands, changing lives — uniting people who want to help with communities and families across Uzbekistan who need genuine care, physical accessibility, and compassionate support.',
  vision: 'A dignified, inclusive society where every elder is remembered, every person with restricted mobility has barrier-free access, and youth lead civic mutual aid with radical transparency.',
  aboutText: 'SAFA is a youth-led community and charity initiative in Uzbekistan. We believe that compassion must be paired with real physical presence. From home grocery deliveries and elder companion checkups to wheelchair ramp construction, every activity is directly organized by our volunteer network and documented with radical transparency.',
  // Aliases for compatibility
  role: 'Founder & CEO of SAFA',
  image: '/nargiza_ceo.jpg',
  bio: 'Nargiza leads SAFA with the conviction that empathy must be paired with action. Mobilizing youth and community volunteers across Tashkent and regional mahallas.'
};

export const INITIAL_SOCIAL_LINKS: SocialLink[] = [
  {
    id: 'soc-tg',
    platform: 'telegram',
    title: 'Telegram Channel',
    url: 'https://t.me/SafaUzbekistan',
    description: 'Real-time updates, active volunteer calls, and event announcements in Uzbekistan.',
    handle: '@SafaUzbekistan',
    enabled: true,
    displayOrder: 1
  },
  {
    id: 'soc-ig',
    platform: 'instagram',
    title: 'Instagram',
    url: 'https://www.instagram.com/safa_uzb_?igsi=MXd0cm5xdWF5ZnZqcA%3D%3D&utm_source=qr',
    description: 'Visual stories, behind-the-scenes drives, and humanitarian volunteer moments.',
    handle: '@safa_uzb_',
    enabled: true,
    displayOrder: 2
  },
  {
    id: 'soc-yt',
    platform: 'youtube',
    title: 'YouTube Channel',
    url: 'https://www.youtube.com/@SafaUzbekistan',
    description: 'Documentary field logs, project timelapses, and volunteer stories in video.',
    handle: '@SafaUzbekistan',
    enabled: true,
    displayOrder: 3
  },
  {
    id: 'soc-linkedin',
    platform: 'linkedin',
    title: 'LinkedIn',
    url: 'https://www.linkedin.com/in/safa-uzbekistan-63080b432?utm_source=share_via&utm_content=profile&utm_medium=member_ios',
    description: 'Professional partnerships, organizational network, and volunteer leadership.',
    handle: 'safa-uzbekistan',
    enabled: true,
    displayOrder: 4
  },
  {
    id: 'soc-email',
    platform: 'email',
    title: 'Official Email',
    url: 'mailto:safaauzb@gmail.com',
    description: 'Direct inquiries, partnership proposals, and official correspondence.',
    handle: 'safaauzb@gmail.com',
    enabled: true,
    displayOrder: 5
  }
];

export const INITIAL_IMPACT_STATS: ImpactStatistic[] = [
  {
    id: 'stat-people',
    metric: '1,100+',
    label: 'People Reached',
    description: 'Directly supported through community visits, food packages, and winter drives last year.',
    period: 'Verified (From Last Year)',
    verifiedAt: '2026-01-15',
    isReal: true
  },
  {
    id: 'stat-projects',
    metric: '38',
    label: 'Projects Completed',
    description: 'Grassroots community actions, medical visit assistances, and facility renovations.',
    period: '2025 – 2026',
    verifiedAt: '2026-02-10',
    isReal: true
  },
  {
    id: 'stat-volunteers',
    metric: '160+',
    label: 'Youth Volunteers',
    description: 'Compassionate young leaders across Tashkent, Samarkand, and surrounding regions.',
    period: 'Active Network',
    verifiedAt: '2026-02-28',
    isReal: true
  },
  {
    id: 'stat-transparency',
    metric: '100%',
    label: 'Documented Actions',
    description: 'Every drive, item delivery, and contribution accounted for in our public archive.',
    period: 'Current Standard',
    verifiedAt: '2026-03-01',
    isReal: true
  }
];

export const WHY_CHOOSE_SAFA = [
  {
    id: 'reach',
    stat: '1,100+',
    tag: 'From last year',
    title: 'People Reached',
    description: 'Direct, tangible assistance delivered right to families and individuals in need through our grassroots initiatives.'
  },
  {
    id: 'youth',
    stat: '100%',
    tag: 'Youth-Led',
    title: 'Powered by Young People Who Care',
    description: 'Mobilizing student volunteers and young professionals who dedicate their personal time to visit and support local communities.'
  },
  {
    id: 'action',
    stat: 'Hands-on',
    tag: 'Real Action',
    title: 'From Donations to Visits & Support',
    description: 'We do not simply transfer funds; we visit homes, deliver groceries, build ramps, and spend time listening to people.'
  },
  {
    id: 'community',
    stat: 'Growing',
    tag: 'Growing Community',
    title: 'Bringing Compassionate People Together',
    description: 'A welcoming space for donors, volunteers, doctors, and students united by civic responsibility and kindness.'
  },
  {
    id: 'impact',
    stat: 'Local First',
    tag: 'Local Impact',
    title: 'Starting From Our Community, Creating Bigger Change',
    description: 'Focused grassroots execution that builds lasting relationships and dignified support structures step by step.'
  }
];

export const INITIAL_PROGRAMS: Program[] = [
  {
    id: 'prog-disability',
    title: 'Disability & Accessibility Support',
    category: 'Accessibility',
    description: 'Equipping homes and community venues with mobility aids, wheelchair ramps, and personal care necessities.',
    longDescription:
      'We partner with local healthcare workers and community leaders to identify individuals living with physical disabilities who lack accessibility modifications. We coordinate volunteer drives to install entry ramps, supply mobility devices, and provide ongoing home visits.',
    status: 'active',
    location: 'Tashkent & Surrounding Regions',
    peopleHelped: '280+ individuals',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80',
    ctaText: 'Support Accessibility',
    ctaLink: '/support?program=disability'
  },
  {
    id: 'prog-elderly',
    title: 'Elderly Care & Social Companion Visits',
    category: 'Elderly Care',
    description: 'Combating isolation among lonely seniors through weekly companionship, warm meals, and medication pickups.',
    longDescription:
      'Elderly individuals living alone are among the most vulnerable members of our society. Our youth teams make consistent home visits, deliver fresh groceries, handle routine household repairs, and most importantly, offer sincere human conversation and respect.',
    status: 'active',
    location: 'Mahallas across Tashkent',
    peopleHelped: '340+ elderly residents',
    image: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=800&q=80',
    ctaText: 'Support Elderly Care',
    ctaLink: '/support?program=elderly'
  },
  {
    id: 'prog-family',
    title: 'Vulnerable Family Assistance',
    category: 'Family Assistance',
    description: 'Emergency food packages, winter heating fuels, and essential home supplies for families under severe hardship.',
    longDescription:
      'Working closely with neighborhood mahalla committees, we identify families with multiple children or unexpected breadwinner loss. We supply staple nutrition, winter jackets, bedding, and infant care products directly into their hands.',
    status: 'active',
    location: 'Community Centers in Uzbekistan',
    peopleHelped: '420+ families',
    image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80',
    ctaText: 'Support Families',
    ctaLink: '/support?program=family'
  },
  {
    id: 'prog-education',
    title: 'Youth Education & School Kits',
    category: 'Education',
    description: 'Equipping underprivileged schoolchildren with backpacks, stationery, books, and youth mentorship.',
    longDescription:
      'Every child deserves the tools to learn with dignity. Before each school term, SAFA volunteers assemble and deliver complete educational bundles, host motivational talks, and provide reading circles.',
    status: 'active',
    location: 'Regional Public Schools',
    peopleHelped: '250+ students',
    image: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80',
    ctaText: 'Support Students',
    ctaLink: '/support?program=education'
  },
  {
    id: 'prog-emergency',
    title: 'Emergency Community Relief',
    category: 'Emergency Relief',
    description: 'Rapid mobilization for unforeseen crises, emergency medical costs, and severe seasonal hardships.',
    longDescription:
      'When immediate support is vital for urgent prescription medicines, temporary shelters, or seasonal cold waves, SAFA organizes swift volunteer dispatch teams with verified receipts and documentation.',
    status: 'active',
    location: 'Multi-region deployment',
    peopleHelped: '110+ emergency cases',
    image: 'https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=800&q=80',
    ctaText: 'Support Relief Fund',
    ctaLink: '/support?program=emergency'
  }
];

export const INITIAL_WORK_ITEMS: WorkItem[] = [
  {
    id: 'work-1',
    slug: 'winter-warmth-drive-tashkent-mahallas',
    title: 'Winter Warmth Drive: Essential Supplies & Warm Blankets',
    summary: 'Delivered winter coats, insulated blankets, and staple grocery packages to 45 vulnerable families and elderly seniors.',
    description:
      'During sub-zero cold spells in Tashkent, SAFA youth volunteers conducted door-to-door deliveries in multiple neighborhood mahallas. We distributed 45 packages containing warm winter jackets, blankets, flour, cooking oil, rice, and hygiene essentials. All items were acquired with verified public contributions and transported with volunteer cars.',
    coverImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    category: 'Family Assistance',
    location: 'Yunusabad & Chilonzor Districts, Tashkent',
    eventDate: '2026-01-22',
    supportedCommunity: '45 Low-Income Families & Single Seniors',
    status: 'published',
    verificationStatus: 'verified',
    contributionAmount: 18500000,
    currency: 'UZS',
    reportUrl: '/reports/winter-drive-2026.pdf',
    gallery: [
      {
        id: 'w1-g1',
        fileUrl: 'https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=800&q=80',
        altText: 'Volunteers organizing packaged winter supplies at community staging point',
        caption: 'Staging point where youth volunteers sorted donations by family size.',
        displayOrder: 1
      },
      {
        id: 'w1-g2',
        fileUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80',
        altText: 'Loading boxes of warm provisions into volunteer vehicles',
        caption: 'Transportation coordinated collaboratively without administrative overhead.',
        displayOrder: 2
      }
    ],
    publishedAt: '2026-01-25',
    verifiedAt: '2026-01-24',
    verifiedBy: 'SAFA Board & Field Verification Team'
  },
  {
    id: 'work-2',
    slug: 'accessibility-ramp-installation-drive',
    title: 'Accessible Entrances: Community Ramp Construction',
    summary: 'Constructed safe, permanent concrete wheelchair ramps for two residential apartment entrances housing mobility-impaired residents.',
    description:
      'For over three years, two elderly residents with mobility impairments were unable to leave their homes without multiple neighbors lifting their heavy wheelchairs down steep stairs. SAFA youth volunteers partnered with local builders, purchased safe handrails and concrete, and constructed accessibility ramps compliant with safety standards.',
    coverImage: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1200&q=80',
    category: 'Disability Support',
    location: 'Sergeli District, Tashkent',
    eventDate: '2026-02-04',
    supportedCommunity: 'Residential neighborhood & 2 wheelchair-bound residents',
    status: 'published',
    verificationStatus: 'verified',
    contributionAmount: 8200000,
    currency: 'UZS',
    reportUrl: '/reports/accessibility-project-2026-01.pdf',
    gallery: [
      {
        id: 'w2-g1',
        fileUrl: 'https://images.unsplash.com/photo-1504917599217-d4dc5ebe6122?auto=format&fit=crop&w=800&q=80',
        altText: 'Volunteers and local masons pouring smooth concrete ramp',
        caption: 'Ramp grade and surface finishing inspected for wheelchair safety.',
        displayOrder: 1
      }
    ],
    publishedAt: '2026-02-07',
    verifiedAt: '2026-02-06',
    verifiedBy: 'Lead Field Coordinator'
  },
  {
    id: 'work-3',
    slug: 'elderly-companion-health-care-visit',
    title: 'Grandparents of the Mahalla: Companion Care Visits',
    summary: 'Visited 28 single elderly residents to conduct basic health checks, deliver monthly prescription refills, and provide companionship.',
    description:
      'Isolation can severely deteriorate physical and mental health. A team of medical student volunteers and youth members visited 28 homes, measured blood pressure, organized medication schedules, and delivered grocery hampers tailored to diabetic and low-sodium dietary requirements.',
    coverImage: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=1200&q=80',
    category: 'Elderly Care',
    location: 'Old City, Tashkent & Shaykhontohur',
    eventDate: '2026-02-18',
    supportedCommunity: '28 Elderly residents living independently',
    status: 'published',
    verificationStatus: 'verified',
    contributionAmount: 6400000,
    currency: 'UZS',
    reportUrl: '/reports/elderly-companion-visit-feb2026.pdf',
    gallery: [
      {
        id: 'w3-g1',
        fileUrl: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80',
        altText: 'Friendly tea and conversation with elder resident in traditional courtyard',
        caption: 'Spending quality time and listening to elders is at the heart of our mission.',
        displayOrder: 1
      }
    ],
    publishedAt: '2026-02-20',
    verifiedAt: '2026-02-19',
    verifiedBy: 'SAFA Verification Committee'
  },
  {
    id: 'work-4',
    slug: 'spring-school-kits-distribution',
    title: 'Schooling With Dignity: Backpacks & Stationery Drive',
    summary: 'Assembled and gifted 80 complete school stationery kits and sturdy backpacks to pupils in need.',
    description:
      'We believe every young person should walk into their classroom holding their head high. SAFA packed backpacks with notebooks, mathematical drawing sets, quality pens, color pencils, and water bottles for 80 children identified by mahalla educational advisors.',
    coverImage: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=80',
    category: 'Education',
    location: 'Tashkent Region Districts',
    eventDate: '2026-02-27',
    supportedCommunity: '80 Elementary and Middle School Students',
    status: 'published',
    verificationStatus: 'verified',
    contributionAmount: 11200000,
    currency: 'UZS',
    reportUrl: '/reports/education-kits-feb2026.pdf',
    gallery: [],
    publishedAt: '2026-03-01',
    verifiedAt: '2026-02-28',
    verifiedBy: 'Nargiza & Education Program Lead'
  }
];

export const INITIAL_STORIES: Story[] = [
  {
    id: 'story-1',
    title: 'How a Simple Ramp Restored Independence to Bobur Aka',
    summary: 'After three years indoors, a community-built ramp gave a resident back his connection to the outside world.',
    body:
      'For over three years, 54-year-old Bobur aka had to plan every trip outside around the schedules of neighbors willing to carry his wheelchair down steep entrance stairs. When our volunteers learned of the situation, we raised the funds for materials within 48 hours and completed construction over the weekend.\n\nToday, Bobur aka sits outside in the spring sun, greets his neighbors on morning walks, and shops at the local bakery independently. "You did not just pour concrete," he shared with our team, "you gave me my dignity and freedom back."',
    coverImage: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=900&q=80',
    category: 'Disability Support',
    author: 'Nargiza (Founder & CEO)',
    date: '2026-02-12',
    consentStatus: 'verified_consent',
    publishedAt: '2026-02-12',
    status: 'published'
  },
  {
    id: 'story-2',
    title: 'The Warmth of a Shared Teapot with Anora Oya',
    summary: 'Behind every delivery of groceries is an afternoon of heartfelt conversation, memories, and restored belonging.',
    body:
      'Anora oya lives alone in a quiet courtyard in the historical quarter. Her memory of our first visit was not about the sacks of flour or cooking oil: "You took off your boots, sat on the tapchan, and drank green tea with me for an hour while I told stories about my youth."\n\nAt SAFA, we train every youth volunteer to understand that loneliness is as heavy as material hardship. Regular visits from respectful youth remind our elders that our community still honors and remembers them.',
    coverImage: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=900&q=80',
    category: 'Elderly Care',
    author: 'Volunteer Field Team',
    date: '2026-02-22',
    consentStatus: 'verified_consent',
    publishedAt: '2026-02-22',
    status: 'published'
  }
];

export const INITIAL_HISTORY_TIMELINE: HistoryEntry[] = [
  {
    id: 'hist-1',
    year: '2026',
    date: 'January 2026',
    title: 'SAFA Platform Established',
    description:
      'Founded by Nargiza and a passionate group of youth leaders with the core motto "Connecting Hands, Changing Lives" to bring radical transparency and direct action to community charity.',
    verifiedImpact: 'Organizational charter formalized, initial volunteer cohort organized'
  },
  {
    id: 'hist-2',
    year: '2026',
    date: 'January 2026',
    title: 'First Emergency Winter Warmth Campaign',
    description:
      'Successfully launched first coordinated grassroots winter campaign providing fuel and warm clothes to 45 households in freezing conditions.',
    verifiedImpact: '45 families protected from winter cold, 100% photo-verified receipts'
  },
  {
    id: 'hist-3',
    year: '2026',
    date: 'February 2026',
    title: 'Community Accessibility Initiative',
    description:
      'Expanded focus into barrier-free living, constructing neighborhood wheelchair ramps and coordinating specialized medical mobility devices.',
    verifiedImpact: 'Permanent ramp installations, barrier removal in 2 residential sectors'
  },
  {
    id: 'hist-4',
    year: '2026',
    date: 'Current',
    title: 'Expanding Regional Volunteer Hubs',
    description:
      'Growing the youth volunteer network across multiple regions in Uzbekistan to respond rapidly to local neighborhood requests.',
    verifiedImpact: 'Over 1,100 people supported through collective grassroots programs'
  }
];

export const INITIAL_CONTRIBUTIONS: Contribution[] = [
  {
    id: 'c-1001',
    contributionNumber: 'SAFA-2026-000001',
    amount: 1500000,
    currency: 'UZS',
    purpose: 'Winter Warmth Relief Fund',
    projectName: 'Winter Warmth Drive',
    donorName: 'Farrukh T.',
    isAnonymous: false,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    createdAt: '2026-01-18T10:14:00Z',
    verifiedAt: '2026-01-18T11:00:00Z'
  },
  {
    id: 'c-1002',
    contributionNumber: 'SAFA-2026-000002',
    amount: 500000,
    currency: 'UZS',
    purpose: 'Elderly Care & Medication Support',
    projectName: 'Companion Care Visits',
    donorName: 'Anonymous Supporter',
    isAnonymous: true,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    createdAt: '2026-01-20T14:22:00Z',
    verifiedAt: '2026-01-20T15:10:00Z'
  },
  {
    id: 'c-1003',
    contributionNumber: 'SAFA-2026-000003',
    amount: 2500000,
    currency: 'UZS',
    purpose: 'Wheelchair Ramp Construction',
    projectName: 'Accessibility Ramp Installation',
    donorName: 'Dilshod & Family',
    isAnonymous: false,
    paymentMethod: 'bank_transfer',
    status: 'completed',
    createdAt: '2026-02-02T09:30:00Z',
    verifiedAt: '2026-02-02T10:05:00Z'
  },
  {
    id: 'c-1004',
    contributionNumber: 'SAFA-2026-000004',
    amount: 300000,
    currency: 'UZS',
    purpose: 'General Community Needs',
    donorName: 'Anonymous Supporter',
    isAnonymous: true,
    paymentMethod: 'card_checkout',
    status: 'completed',
    createdAt: '2026-02-14T18:45:00Z',
    verifiedAt: '2026-02-14T18:46:00Z'
  },
  {
    id: 'c-1005',
    contributionNumber: 'SAFA-2026-000005',
    amount: 1000000,
    currency: 'UZS',
    purpose: 'School Kits for Pupils',
    projectName: 'Schooling With Dignity',
    donorName: 'Madina K.',
    isAnonymous: false,
    paymentMethod: 'card_checkout',
    status: 'completed',
    createdAt: '2026-02-25T11:15:00Z',
    verifiedAt: '2026-02-25T11:16:00Z'
  },
  {
    id: 'c-1006',
    contributionNumber: 'SAFA-2026-000006',
    amount: 100,
    currency: 'USD',
    purpose: 'Youth Volunteer Logistic Support',
    donorName: 'Anonymous Supporter',
    isAnonymous: true,
    paymentMethod: 'card_checkout',
    status: 'completed',
    createdAt: '2026-02-28T16:40:00Z',
    verifiedAt: '2026-02-28T16:41:00Z'
  }
];

export const INITIAL_TRANSPARENCY_REPORTS: TransparencyReport[] = [
  {
    id: 'rep-1',
    title: 'SAFA Winter Warmth Initiative 2026 — Execution & Audit Summary',
    category: 'project',
    year: '2026',
    fileUrl: '/reports/winter-warmth-2026.pdf',
    fileSize: '1.4 MB',
    publishedAt: '2026-02-01',
    summary: 'Full itemized expense register for 45 household winter packages, supplier receipts, and distribution logs.'
  },
  {
    id: 'rep-2',
    title: 'Sergeli Accessibility Ramps — Materials & Technical Verification Report',
    category: 'project',
    year: '2026',
    fileUrl: '/reports/accessibility-ramps-2026.pdf',
    fileSize: '2.1 MB',
    publishedAt: '2026-02-10',
    summary: 'Material procurement receipts, structural photos, and neighborhood council handover sign-off.'
  },
  {
    id: 'rep-3',
    title: 'SAFA Q1 2026 Contribution & Financial Reconciliation Statement',
    category: 'financial',
    year: '2026',
    fileUrl: '/reports/financial-q1-2026.pdf',
    fileSize: '950 KB',
    publishedAt: '2026-03-01',
    summary: 'Quarterly financial balance, incoming donor contributions, zero administrative leakages verification.'
  }
];

export const INITIAL_BANK_CONFIG: DonationBankConfig = {
  bankName: 'Official Partner Bank (Uzbekistan)',
  accountName: 'SAFA Community Support Initiative',
  accountNumber: '2020 8000 **** **** 0001 [CONFIRM WITH SAFA BOARD]',
  mfo: '00440',
  inn: '309999999',
  currency: 'UZS / USD',
  note: 'Please include your name or "Anonymous" + project purpose in the payment remarks.'
};

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-1',
    name: 'Nargiza',
    email: 'safaauzb@gmail.com',
    role: 'super_admin',
    status: 'active',
    createdAt: '2025-11-01T00:00:00Z',
    lastLoginAt: '2026-03-02T10:00:00Z'
  },
  {
    id: 'usr-2',
    name: 'Ahmed K.',
    email: 'ahmed@safa.uz',
    role: 'content_manager',
    status: 'active',
    createdAt: '2026-01-10T00:00:00Z',
    lastLoginAt: '2026-03-01T14:21:00Z',
    invitedBy: 'Nargiza'
  },
  {
    id: 'usr-3',
    name: 'Malika T.',
    email: 'malika@safa.uz',
    role: 'media_manager',
    status: 'active',
    createdAt: '2026-01-15T00:00:00Z',
    lastLoginAt: '2026-03-02T09:15:00Z',
    invitedBy: 'Nargiza'
  },
  {
    id: 'usr-4',
    name: 'Aziz R.',
    email: 'aziz@safa.uz',
    role: 'editor',
    status: 'active',
    createdAt: '2026-01-18T00:00:00Z',
    lastLoginAt: '2026-03-01T18:40:00Z',
    invitedBy: 'Nargiza'
  },
  {
    id: 'usr-5',
    name: 'Shahnoza K.',
    email: 'finance@safa.uz',
    role: 'finance',
    status: 'active',
    createdAt: '2026-01-20T00:00:00Z',
    lastLoginAt: '2026-02-28T16:00:00Z',
    invitedBy: 'Nargiza'
  },
  {
    id: 'usr-6',
    name: 'Bobur M.',
    email: 'volunteers@safa.uz',
    role: 'volunteer_manager',
    status: 'active',
    createdAt: '2026-01-22T00:00:00Z',
    lastLoginAt: '2026-03-02T08:30:00Z',
    invitedBy: 'Nargiza'
  }
];

export const INITIAL_INVITATIONS: AdminInvitation[] = [
  {
    id: 'inv-1',
    token: 'safa-inv-dilorom-2026',
    name: 'Dilorom S.',
    email: 'dilorom@safa.uz',
    role: 'content_manager',
    invitedBy: 'usr-1',
    invitedByName: 'Nargiza',
    createdAt: '2026-03-01T12:00:00Z',
    expiresAt: '2026-03-08T12:00:00Z',
    status: 'pending'
  }
];

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'safa-community-visit-tashkent-winter',
    title: 'SAFA Field Visit: Delivering Warmth & Essentials to 25 Households in Chilanzar',
    excerpt: 'Behind the scenes with the SAFA volunteer team during the February sub-zero cold snap in Tashkent.',
    content: `During the recent drop in temperatures across the Tashkent region, the SAFA volunteer squad mobilized a targeted emergency response. 

Coordinated through local mahalla elders, our teams visited 25 households with elderly pensioners and families with young children facing heating vulnerabilities. 

Each household received an insulated winter blanket set, a dry foods package containing flour, vegetable oil, rice, tea, and sugar, as well as essential personal care supplies. 

Our core philosophy remains direct delivery: no third-party warehousing, no administrative delays. Every volunteer verified delivery by signing the field checklist alongside community representatives.`,
    coverImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80'
    ],
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    author: 'Ahmed K.',
    authorRole: 'Content Manager',
    authorId: 'usr-2',
    category: 'Community Visits',
    tags: ['Winter Relief', 'Tashkent', 'Elders Care', 'Direct Aid'],
    location: 'Chilanzar, Tashkent',
    date: '2026-02-18',
    publishedAt: '2026-02-19T10:00:00Z',
    seoTitle: 'SAFA Field Visit: Delivering Warmth in Chilanzar | SAFA Uzbekistan',
    seoDescription: 'Verified field report on SAFA community response during Tashkent winter freezing temperatures.',
    status: 'published',
    reviewedBy: 'Aziz R.'
  },
  {
    id: 'art-2',
    slug: 'accessible-infrastructure-mahallas',
    title: 'Dignity Through Mobility: Why Small Ramp Installations Transform Neighborhoods',
    excerpt: 'Reflections from our accessibility engineering volunteers on building concrete ramps for wheelchair users.',
    content: `A simple curb or two concrete steps can become an insurmountable barrier for individuals relying on wheelchairs or walkers. 

Over the past four months, SAFA has completed 12 access ramps across Sergeli and Yunusabad mahalla courtyards. In this article, our field coordinator breaks down the technical measurements, materials selection, and the human impact of granting someone the autonomy to leave their home unassisted.

We ensure all construction conforms to non-slip textures and safe inclines under 8% gradient.`,
    coverImage: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=1200&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=800&q=80'
    ],
    author: 'Ahmed K.',
    authorRole: 'Content Manager',
    authorId: 'usr-2',
    category: 'Accessibility',
    tags: ['Accessibility', 'Inclusion', 'Ramps', 'Mobility'],
    location: 'Sergeli & Yunusabad, Tashkent',
    date: '2026-02-26',
    publishedAt: '2026-02-27T14:30:00Z',
    status: 'published',
    reviewedBy: 'Aziz R.'
  },
  {
    id: 'art-3',
    slug: 'spring-community-grocery-drive-preview',
    title: 'Upcoming Spring 2026 Community Drive: Route & Volunteer Registration',
    excerpt: 'Detailed schedule and distribution route for our March Navruz holiday support campaign.',
    content: `As Navruz approaches, SAFA is preparing food baskets for 80 families across Samarkand and Bukhara regions. This draft outlines logistical checkpoints, supplier price agreements, and volunteer muster points.`,
    coverImage: 'https://images.unsplash.com/photo-1532629345422-7515f3d16bb0?auto=format&fit=crop&w=1200&q=80',
    galleryImages: [],
    author: 'Ahmed K.',
    authorRole: 'Content Manager',
    authorId: 'usr-2',
    category: 'Campaigns',
    tags: ['Navruz', 'Food Drive', 'Samarkand'],
    location: 'Samarkand Region',
    date: '2026-03-01',
    status: 'submitted',
    reviewNotes: 'Ready for editorial review and date confirmation with regional volunteers.'
  }
];

export const INITIAL_VIDEOS: VideoItem[] = [
  {
    id: 'vid-1',
    title: 'Winter Warmth Drive 2026 — Official Field Log',
    description: 'A 3-minute video montage documenting our volunteer loading, transportation, and home visits across Tashkent.',
    youtubeUrl: 'https://www.youtube.com/watch?v=7hP-w49bAeo',
    thumbnailUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80',
    category: 'Field Action',
    relatedProjectId: 'work-1',
    author: 'Malika T.',
    status: 'published',
    publishedAt: '2026-02-05T12:00:00Z',
    duration: '3:45'
  },
  {
    id: 'vid-2',
    title: 'Building Hope: Concrete Ramp Installation in Sergeli',
    description: 'Technical timelapse and resident interview during the Sergeli apartment block entrance renovation.',
    youtubeUrl: 'https://www.youtube.com/watch?v=kXYiU_JCYtU',
    thumbnailUrl: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=800&q=80',
    category: 'Accessibility',
    relatedProjectId: 'work-2',
    author: 'Malika T.',
    status: 'published',
    publishedAt: '2026-02-12T15:00:00Z',
    duration: '4:20'
  }
];

export const INITIAL_PHOTO_ALBUMS: PhotoAlbum[] = [
  {
    id: 'alb-1',
    title: 'Winter Relief Drive — February 2026',
    description: '45 curated photos capturing community delivery, volunteer teams, and transparent handovers in Tashkent.',
    coverImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80',
    photos: [
      { id: 'p-1', url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80', caption: 'Loading grocery cartons onto volunteer vehicles' },
      { id: 'p-2', url: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80', caption: 'Home visit and warmth blanket handover' },
      { id: 'p-3', url: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=800&q=80', caption: 'Field committee verification signing' }
    ],
    date: '2026-02-18',
    location: 'Tashkent, Uzbekistan',
    category: 'Community Relief',
    relatedProjectId: 'work-1',
    status: 'published',
    createdAt: '2026-02-18T18:00:00Z'
  },
  {
    id: 'alb-2',
    title: 'Sergeli Ramps Construction & Handover',
    description: 'Documentation of concrete pouring, curing, safety rails installation, and testing with residents.',
    coverImage: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=800&q=80',
    photos: [
      { id: 'p-4', url: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=800&q=80', caption: 'Finished ramp with non-slip coating' },
      { id: 'p-5', url: 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=800&q=80', caption: 'Community assembly and elder handover' }
    ],
    date: '2026-02-10',
    location: 'Sergeli 7, Tashkent',
    category: 'Accessibility',
    relatedProjectId: 'work-2',
    status: 'published',
    createdAt: '2026-02-10T14:00:00Z'
  }
];

export const INITIAL_MEDIA_ASSETS: MediaAsset[] = [
  {
    id: 'med-1',
    filename: 'winter-warmth-hero.jpg',
    title: 'Winter Warmth Distribution Group Photo',
    url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    type: 'image',
    size: '1.8 MB',
    uploadedBy: 'Malika T.',
    uploadedAt: '2026-02-01T09:30:00Z',
    altText: 'SAFA volunteer team packing boxes in warehouse',
    caption: 'Volunteers preparing winter grocery packages for delivery',
    tags: ['winter', 'volunteers', 'groceries']
  },
  {
    id: 'med-2',
    filename: 'sergeli-ramp-completed.jpg',
    title: 'Sergeli Accessibility Ramp',
    url: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=1200&q=80',
    type: 'image',
    size: '2.4 MB',
    uploadedBy: 'Malika T.',
    uploadedAt: '2026-02-10T11:00:00Z',
    altText: 'Completed concrete ramp with yellow safety edge',
    caption: 'Access ramp at Building 14 entrance, Sergeli',
    tags: ['accessibility', 'construction', 'sergeli']
  },
  {
    id: 'med-3',
    filename: 'safa-financial-statement-q1.pdf',
    title: 'Q1 Financial Statement & Ledger Summary',
    url: '/reports/financial-q1-2026.pdf',
    type: 'document',
    size: '950 KB',
    uploadedBy: 'Shahnoza K.',
    uploadedAt: '2026-03-01T08:00:00Z',
    tags: ['finance', 'audit', 'transparency']
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Spring Navruz 2026 Volunteer Registrations Now Open',
    message: 'Join SAFA youth teams in Tashkent and Samarkand as we deliver 80 family grocery boxes this month. Applications are open until March 15.',
    type: 'info',
    active: true,
    linkText: 'Apply as Volunteer',
    linkUrl: '/volunteer',
    startDate: '2026-03-01',
    endDate: '2026-03-20',
    createdAt: '2026-03-01T08:00:00Z'
  }
];

export const INITIAL_EVENTS: EventItem[] = [
  {
    id: 'evt-1',
    slug: 'navruz-community-grocery-drive-2026',
    title: 'Navruz 2026 Family Grocery Pack & Distribution Drive',
    description: 'A major spring holiday mobilization uniting youth volunteers to assemble and hand-deliver nutritious food baskets to 80 vulnerable households in Tashkent and Samarkand.',
    date: '2026-03-20',
    time: '09:00 - 15:00',
    location: 'SAFA Volunteer Hub & Mahallas across Tashkent',
    coverImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    category: 'Community Relief',
    registrationUrl: '/volunteer',
    registrationInfo: 'Open to youth volunteers with driving or packing availability. Advance sign-up required.',
    status: 'upcoming',
    createdAt: '2026-03-01T10:00:00Z'
  },
  {
    id: 'evt-2',
    slug: 'elderly-companion-tea-and-health-day',
    title: 'Grandparents of the Mahalla: Companion Visit & Health Check Day',
    description: 'Youth and medical student volunteers visit 30 elderly residents living alone in the Old City district to deliver prescription medicines, check blood pressure, and share warm tea and conversation.',
    date: '2026-03-28',
    time: '10:00 - 14:00',
    location: 'Shaykhontohur & Old City, Tashkent',
    coverImage: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=1200&q=80',
    category: 'Elderly Care',
    registrationUrl: '/volunteer',
    registrationInfo: 'Volunteers paired in teams of two. Training provided before departure.',
    status: 'upcoming',
    createdAt: '2026-03-02T11:00:00Z'
  },
  {
    id: 'evt-3',
    slug: 'winter-warmth-delivery-wrap-up-feb2026',
    title: 'Winter Warmth 2026 Final Distribution & Review Assembly',
    description: 'Celebrating the successful conclusion of our emergency cold-snap response delivering 250 insulated blankets and 45 heating sets to families in Chilanzar and Sergeli.',
    date: '2026-02-28',
    time: '14:00 - 16:30',
    location: 'Tashkent Youth Civic Center',
    coverImage: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=1200&q=80',
    category: 'Field Action',
    status: 'completed',
    createdAt: '2026-02-15T08:00:00Z'
  }
];

export const INITIAL_DONATION_CAMPAIGNS: DonationCampaign[] = [
  {
    id: 'camp-1',
    title: 'General Community & Emergency Care Fund',
    description: 'Unrestricted funding enabling SAFA to respond immediately to urgent Mahalla calls, winter emergency heating needs, and sudden crises for solitary elders.',
    targetAmount: 50000000,
    raisedAmount: 38400000,
    currency: 'UZS',
    coverImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&q=80',
    status: 'active',
    bankInstructions: 'Specify "General Community Relief" in transfer description.',
    createdAt: '2026-01-01T00:00:00Z'
  },
  {
    id: 'camp-2',
    title: 'Neighborhood Wheelchair Ramps & Accessibility Initiative',
    description: 'Funding concrete materials, anti-slip coating, and safety handrails for apartment entrances where wheelchair users are currently trapped inside.',
    targetAmount: 25000000,
    raisedAmount: 16800000,
    currency: 'UZS',
    coverImage: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=1200&q=80',
    status: 'active',
    bankInstructions: 'Specify "Accessibility Ramps Fund" in transfer description.',
    createdAt: '2026-02-01T00:00:00Z'
  },
  {
    id: 'camp-3',
    title: 'Prescriptions & Nutritious Groceries for Solitary Elders',
    description: 'Providing monthly medication refills and diabetic-appropriate food supplies for 50 single pensioners across Tashkent.',
    targetAmount: 20000000,
    raisedAmount: 18200000,
    currency: 'UZS',
    coverImage: 'https://images.unsplash.com/photo-1516307365426-bea591f05011?auto=format&fit=crop&w=1200&q=80',
    status: 'active',
    bankInstructions: 'Specify "Elderly Care Support" in transfer description.',
    createdAt: '2026-02-15T00:00:00Z'
  }
];

