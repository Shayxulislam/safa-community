import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Heart, Users, Shield } from 'lucide-react';
import { Button } from '../ui/Button';

export const AboutSection: React.FC = () => {
  return (
    <section className="py-16 sm:py-24 bg-[#F1EDE4]/30 border-b border-[#E5E0D5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 order-2 lg:order-1">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=1000&q=80"
                alt="SAFA team working together in community"
                className="w-full h-96 object-cover rounded-[2.5rem] shadow-md border border-[#E5E0D5]"
              />
              <div className="absolute -bottom-6 -right-6 bg-white/95 backdrop-blur-md p-5 rounded-[2rem] border border-[#E5E0D5] shadow-lg max-w-xs hidden sm:block">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#F1EDE4] text-[#5E6E52] flex items-center justify-center shrink-0 border border-[#E5E0D5]">
                    <Heart className="w-5 h-5 fill-[#5E6E52]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#3D3B36]">Dignity First</p>
                    <p className="text-[11px] text-[#6D6A61]">Supporting with respect, privacy, and genuine compassion.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 order-1 lg:order-2 text-left">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-[#F1EDE4] text-[#B06D50] border border-[#E5E0D5] mb-4 shadow-2xs">
              <span>About SAFA</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#3D3B36] tracking-tight leading-tight mb-5">
              Turning Compassion into Practical, Direct Action
            </h2>

            <p className="text-base sm:text-lg text-[#6D6A61] leading-relaxed mb-6">
              SAFA is an independent community initiative designed to bridge the gap between people who want to contribute and communities facing tangible life hardships across Uzbekistan.
            </p>

            <div className="space-y-3.5 mb-8">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#5E6E52] shrink-0 mt-0.5" />
                <p className="text-sm text-[#3D3B36]">
                  <strong className="font-semibold text-[#3D3B36]">Direct Field Connection:</strong> We conduct personal home visits, ensuring aid goes directly to intended families.
                </p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#5E6E52] shrink-0 mt-0.5" />
                <p className="text-sm text-[#3D3B36]">
                  <strong className="font-semibold text-[#3D3B36]">Youth Empowerment:</strong> Mobilizing universities, young doctors, and student leaders to take active civic ownership.
                </p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#5E6E52] shrink-0 mt-0.5" />
                <p className="text-sm text-[#3D3B36]">
                  <strong className="font-semibold text-[#3D3B36]">Complete Transparency:</strong> Open financial summaries, verified receipts, and public contribution records.
                </p>
              </div>
            </div>

            <Link to="/about">
              <Button variant="outline" size="md" icon={<ArrowRight className="w-4 h-4" />}>
                Read Full SAFA Story
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};
