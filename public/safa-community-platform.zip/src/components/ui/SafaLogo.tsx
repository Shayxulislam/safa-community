import React from 'react';

interface SafaLogoProps {
  variant?: 'full' | 'mark' | 'horizontal';
  className?: string;
  size?: number | string;
  color?: string;
}

export const SafaLogo: React.FC<SafaLogoProps> = ({
  variant = 'mark',
  className = '',
  size = 40,
  color = '#0056D2'
}) => {
  if (variant === 'full') {
    return (
      <div className={`relative inline-flex items-center justify-center ${className}`}>
        <img
          src="/safa-logo.svg"
          alt="SAFA - Connecting Hands, Changing Lives"
          style={{ width: size, height: size }}
          className="object-contain"
        />
      </div>
    );
  }

  if (variant === 'horizontal') {
    return (
      <div className={`inline-flex items-center gap-3 ${className}`}>
        <SafaLogo variant="mark" size={size} color={color} />
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-2xl font-serif font-black tracking-tight text-[#172033] leading-none">
              SAFA
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-[#EBF3FC] text-[#0056D2] border border-[#BFDBFE]">
              UZB
            </span>
          </div>
          <span className="text-[11px] text-[#64748B] font-medium tracking-tight mt-0.5">
            Connecting Hands, Changing Lives
          </span>
        </div>
      </div>
    );
  }

  // Default: 'mark' - Emblem icon (Heart + Hands + Dove)
  return (
    <svg
      viewBox="0 0 500 500"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="SAFA Official Emblem"
    >
      <g>
        {/* Dove of Hope */}
        <path
          d="M 235,142 C 238,137 245,130 252,130 C 255,130 258,132 260,135 C 263,130 268,124 274,124 C 275,124 275,126 274,128 C 271,133 268,139 265,145 C 269,146 274,146 277,144 C 278,146 276,148 273,150 C 268,153 262,154 257,152 C 253,157 248,162 242,166 C 241,165 241,163 243,160 C 245,156 248,151 249,147 C 244,148 239,146 235,142 Z"
          fill={color}
        />

        {/* Heart of Compassion */}
        <path
          d="M 250,335 C 230,318 160,265 160,205 C 160,165 192,148 226,160 C 238,164 246,173 250,180 C 254,173 262,164 274,160 C 308,148 340,165 340,205 C 340,265 270,318 250,335 Z"
          fill={color}
        />

        {/* Top-Right Sleeve */}
        <path d="M 300,162 L 350,192 L 320,242 L 270,212 Z" fill={color} />
        <path d="M 296,170 L 338,195" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M 288,183 L 326,206" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
        {/* Reaching Fingers */}
        <path
          d="M 305,200 C 290,215 265,225 248,232 C 240,235 235,232 238,228 C 244,222 258,212 276,200"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 290,212 C 275,224 258,233 246,238 C 240,241 236,238 238,234 C 244,228 260,218 274,208"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 282,225 C 270,234 256,242 247,245 C 242,247 239,245 241,241 C 247,236 260,227 270,220"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 275,235 C 266,242 256,248 249,251 C 245,253 243,251 245,247 C 249,243 258,236 265,230"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Bottom-Left Sleeve */}
        <path d="M 198,340 L 150,310 L 180,260 L 228,290 Z" fill={color} />
        <path d="M 204,332 L 162,307" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M 212,319 L 174,296" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
        {/* Reaching Fingers */}
        <path
          d="M 195,300 C 210,285 235,275 252,268 C 260,265 265,268 262,272 C 256,278 242,288 224,300"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 210,288 C 225,276 242,267 254,262 C 260,259 264,262 262,266 C 256,272 240,282 226,292"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 218,275 C 230,266 244,258 253,255 C 258,253 261,255 259,259 C 253,264 240,273 230,280"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 225,265 C 234,258 244,252 251,249 C 255,247 257,249 255,253 C 251,257 242,264 235,270"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
    </svg>
  );
};
