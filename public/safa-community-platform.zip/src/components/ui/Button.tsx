import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  icon,
  className = '',
  disabled,
  ...props
}) => {
  const base = 'inline-flex items-center justify-center font-medium transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer select-none';

  const variants = {
    primary: 'bg-[#5E6E52] text-white hover:bg-[#4E5C43] active:bg-[#3E4A35] focus-visible:outline-[#5E6E52] shadow-xs hover:shadow-sm',
    secondary: 'bg-[#F1EDE4] text-[#5E6E52] hover:bg-[#E6E0D4] active:bg-[#DBD4C6] border border-[#E5E0D5] focus-visible:outline-[#5E6E52]',
    outline: 'border border-[#E5E0D5] bg-white text-[#3D3B36] hover:bg-[#F1EDE4]/50 hover:border-[#D5CFC3] focus-visible:outline-[#5E6E52] shadow-xs',
    ghost: 'text-[#3D3B36] hover:bg-[#F1EDE4]/70 active:bg-[#E6E0D4] focus-visible:outline-[#5E6E52]',
    danger: 'bg-[#B06D50] text-white hover:bg-[#97583D] active:bg-[#7D452E] focus-visible:outline-[#B06D50]'
  };

  const sizes = {
    sm: 'text-xs px-3.5 py-1.5 rounded-full gap-1.5 min-h-[36px]',
    md: 'text-sm px-4.5 py-2 rounded-xl gap-2 min-h-[40px]',
    lg: 'text-base px-6 py-3 rounded-xl gap-2.5 min-h-[46px]'
  };

  return (
    <button
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={disabled}
      {...props}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span>{children}</span>
    </button>
  );
};
